# Support

This repository contains sample code provided by GitHub for demonstration purposes.

- **No Official Support**: These samples are provided "as-is" without official support.
- **Use at Your Own Risk**: Intended for learning and experimentation, not for production use.

Thank you for understanding.
