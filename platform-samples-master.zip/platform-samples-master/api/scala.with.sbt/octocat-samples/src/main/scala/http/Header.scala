package http

/**
  *
  * @param property name of the header
  * @param value value of the header
  */
class Header(val property:String, val value:String) {}
