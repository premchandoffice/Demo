rendering-data-as-graphs
================

This is the sample project built by following the "[Rendering Data as Graphs][rendering data]"
guide on developer.github.com.

To run these projects, make sure you have [Bundler][bundler] installed; then type
`bundle install` on the command line.

Then, enter `bundle exec rackup -p 4567` on the command line.

[rendering data]: http://developer.github.com/guides/rendering-data-as-graphs/
[bundler]: http://gembundler.com/
